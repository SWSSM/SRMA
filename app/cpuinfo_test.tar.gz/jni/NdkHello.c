#include "NdkHello.h"
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>

#include <errno.h>
#include <jni.h>
#include <linux/unistd.h>
#include <sys/syscall.h>

#define __NR_printStar 376
#define BUFF_SIZE	 2048

int flag = 1;
int call_syscall = 1;
void hello_world(void)
{
    call_syscall = 10;
    flag = syscall(__NR_printStar, call_syscall);
}

jstring JNICALL Java_com_example_ndkhello_NdkHello_getMsgFromJni(JNIEnv *env, jobject thiz){
	char hello[30];
	hello_world();
	sprintf(hello, "%d Hello from choes %d", flag, call_syscall);
	return (*env)->NewStringUTF(env, hello);
}
jstring JNICALL Java_com_example_ndkhello_NdkHello_getSystemInfo(JNIEnv *env, jobject thiz){
	int fd;
	char buff[BUFF_SIZE];
	//jstring str;

	if((fd = open("/dev/rma_cpuinfo", O_RDWR, 777)) > 0){
		//write(fd, str_hello, strlen(str_hello)+1);

		read(fd, buff, BUFF_SIZE);
		close(fd);
	}

	//(*env)->DeleteLocalRef(env, buff);
	//return str;
	return (*env)->NewStringUTF(env, buff);
}
