package com.example.ndkhello;

import android.os.*;
import android.app.*;
import android.view.*;
import android.widget.*;

public class MainActivity extends Activity {
	NdkHello ndkHello;
	TextView otv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        ndkHello = new NdkHello();
        TextView tv = (TextView)findViewById(R.id.textView);
        tv.setText(ndkHello.getMsgFromJni());
        
        Button button = (Button)findViewById(R.id.button);
        otv = (TextView)findViewById(R.id.outputText);
        button.setOnClickListener(new View.OnClickListener() {
		
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				otv.setText(ndkHello.getSystemInfo());
			}
		});
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }
}
