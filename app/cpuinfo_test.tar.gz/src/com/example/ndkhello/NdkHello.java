package com.example.ndkhello;

public class NdkHello {
	static{
		System.loadLibrary("HelloLibrary");
	}
	public native String getMsgFromJni();
	public native String getSystemInfo();
}
